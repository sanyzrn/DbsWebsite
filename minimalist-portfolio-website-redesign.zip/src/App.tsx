const featuredWork = [
  {
    name: "Northline Studio",
    category: "Brand identity + portfolio",
    description:
      "A stripped-back identity and portfolio site built around typography, rhythm, and a confident monochrome palette.",
    bullets: ["Wordmark & type scale", "Editorial layout system", "Responsive front-end build"],
    gradient: "linear-gradient(135deg, #18181b 0%, #52525b 100%)",
  },
  {
    name: "Terra House",
    category: "Web design + launch assets",
    description:
      "A warm digital presence for a design-led interior brand, balancing softness, clarity, and conversion-focused structure.",
    bullets: ["Landing page design", "Campaign visuals", "Mobile-first experience"],
    gradient: "linear-gradient(135deg, #8f7254 0%, #d5bca2 100%)",
  },
  {
    name: "Object Theory",
    category: "Creative direction + website",
    description:
      "A modern showcase for a multidisciplinary practice, combining visual restraint with flexible content blocks and smooth navigation.",
    bullets: ["Art direction", "Component-based UI", "Content-led storytelling"],
    gradient: "linear-gradient(135deg, #334155 0%, #94a3b8 100%)",
  },
] as const;

const services = [
  {
    title: "Brand systems",
    text: "Identity design, typography direction, color systems, and practical rules that keep everything consistent.",
  },
  {
    title: "Website design",
    text: "Clean, strategic interfaces that feel premium, work responsively, and support real business goals.",
  },
  {
    title: "Front-end build",
    text: "Fast, polished websites built with modern tools and careful attention to detail, spacing, and motion.",
  },
  {
    title: "Creative support",
    text: "Digital collateral, launch graphics, presentation layouts, and ongoing design help for growing brands.",
  },
] as const;

const principles = [
  {
    step: "01",
    title: "Clarify",
    text: "Start with positioning, audience, and structure so the design feels intentional from the beginning.",
  },
  {
    step: "02",
    title: "Refine",
    text: "Shape a visual language that feels quiet, modern, and unmistakably aligned with the brand.",
  },
  {
    step: "03",
    title: "Launch",
    text: "Build a reliable front end, optimize the experience, and deliver something easy to maintain.",
  },
] as const;

const metrics = [
  { value: "Minimal", label: "visual language" },
  { value: "Responsive", label: "from first sketch" },
  { value: "Strategic", label: "creative decisions" },
  { value: "Modern", label: "design + code stack" },
] as const;

const tags = ["Identity systems", "Portfolio websites", "Creative coding", "Editorial layouts"] as const;

export default function App() {
  const year = new Date().getFullYear();

  return (
    <div className="min-h-screen overflow-hidden bg-[var(--bg)] text-[var(--ink)]">
      <div aria-hidden="true" className="pointer-events-none fixed inset-0 -z-10 overflow-hidden">
        <div className="absolute left-[-7rem] top-24 h-72 w-72 rounded-full bg-[#d8c3ab]/60 blur-3xl" />
        <div className="absolute right-[-5rem] top-16 h-64 w-64 rounded-full bg-white/80 blur-3xl" />
        <div className="absolute bottom-0 left-1/3 h-80 w-80 rounded-full bg-[#c4d0df]/35 blur-3xl" />
      </div>

      <header id="top" className="sticky top-0 z-40 px-6 py-5 lg:px-10">
        <div className="mx-auto flex max-w-6xl items-center justify-between rounded-full border border-[var(--line)] bg-white/75 px-5 py-3 shadow-[0_12px_40px_-30px_rgba(0,0,0,0.6)] backdrop-blur-xl">
          <a href="#top" className="flex items-center gap-3">
            <span className="inline-flex h-9 w-9 items-center justify-center rounded-full bg-[#171717] text-sm font-semibold text-white">
              DB
            </span>
            <div>
              <p className="text-sm font-medium tracking-[0.24em] text-[var(--muted)] uppercase">DBS Studio</p>
            </div>
          </a>

          <nav className="hidden items-center gap-6 text-sm text-[var(--muted)] md:flex">
            <a href="#work" className="transition hover:text-[var(--ink)]">
              Work
            </a>
            <a href="#services" className="transition hover:text-[var(--ink)]">
              Services
            </a>
            <a href="#about" className="transition hover:text-[var(--ink)]">
              Process
            </a>
            <a href="#contact" className="transition hover:text-[var(--ink)]">
              Contact
            </a>
          </nav>

          <a
            href="mailto:hello@dbs.studio"
            className="rounded-full border border-[#171717] bg-[#171717] px-4 py-2 text-sm font-medium text-white transition hover:bg-black"
          >
            Start a project
          </a>
        </div>
      </header>

      <main className="px-6 pb-16 lg:px-10 lg:pb-24">
        <section className="mx-auto mt-4 grid max-w-6xl gap-6 lg:grid-cols-[1.35fr_0.85fr]">
          <div className="rounded-[36px] border border-[var(--line)] bg-white/70 p-8 shadow-[0_28px_90px_-48px_rgba(0,0,0,0.45)] backdrop-blur-xl lg:p-12">
            <p className="inline-flex rounded-full border border-[var(--line)] bg-[var(--surface-strong)] px-4 py-2 text-xs font-medium uppercase tracking-[0.24em] text-[var(--muted)]">
              Graphic designer & web developer
            </p>

            <h1 className="mt-8 max-w-4xl text-5xl font-semibold leading-[0.95] tracking-tight sm:text-6xl lg:text-7xl">
              Minimal brands.
              <br />
              Thoughtful websites.
            </h1>

            <p className="mt-6 max-w-2xl text-base leading-7 text-[var(--muted)] sm:text-lg">
              I create clear visual identities and elegant web experiences for studios, founders, and creative businesses
              that want to feel modern, calm, and memorable.
            </p>

            <div className="mt-8 flex flex-wrap gap-3">
              <a
                href="#work"
                className="rounded-full border border-[#171717] bg-[#171717] px-5 py-3 text-sm font-medium text-white transition hover:bg-black"
              >
                View selected work
              </a>
              <a
                href="#services"
                className="rounded-full border border-[var(--line)] bg-[var(--surface-strong)] px-5 py-3 text-sm font-medium text-[var(--ink)] transition hover:bg-white"
              >
                Explore services
              </a>
            </div>

            <div className="mt-10 flex flex-wrap gap-3 text-sm text-[var(--muted)]">
              {tags.map((tag) => (
                <span key={tag} className="rounded-full border border-[var(--line)] px-4 py-2">
                  {tag}
                </span>
              ))}
            </div>
          </div>

          <div className="grid gap-6">
            <div className="rounded-[36px] border border-[var(--line)] bg-[var(--surface)] p-6 backdrop-blur-xl">
              <div className="flex items-center justify-between">
                <p className="text-xs font-medium uppercase tracking-[0.24em] text-[var(--muted)]">At a glance</p>
                <span className="rounded-full border border-[var(--line)] px-3 py-1 text-xs text-[var(--muted)]">
                  Available for freelance
                </span>
              </div>

              <div className="mt-6 space-y-5">
                {services.slice(0, 3).map((service) => (
                  <div key={service.title} className="border-t border-[var(--line)] pt-5 first:border-t-0 first:pt-0">
                    <h2 className="text-lg font-semibold">{service.title}</h2>
                    <p className="mt-2 text-sm leading-6 text-[var(--muted)]">{service.text}</p>
                  </div>
                ))}
              </div>
            </div>

            <div className="grid grid-cols-2 gap-4">
              {metrics.map((metric) => (
                <div
                  key={metric.label}
                  className="rounded-[28px] border border-[var(--line)] bg-white/70 p-5 text-center shadow-[0_16px_50px_-40px_rgba(0,0,0,0.65)]"
                >
                  <p className="text-2xl font-semibold tracking-tight">{metric.value}</p>
                  <p className="mt-2 text-xs uppercase tracking-[0.22em] text-[var(--muted)]">{metric.label}</p>
                </div>
              ))}
            </div>
          </div>
        </section>

        <section id="work" className="mx-auto mt-20 max-w-6xl">
          <div className="flex flex-col gap-4 sm:flex-row sm:items-end sm:justify-between">
            <div>
              <p className="text-xs font-medium uppercase tracking-[0.24em] text-[var(--muted)]">Selected work</p>
              <h2 className="mt-3 text-3xl font-semibold tracking-tight sm:text-4xl">Elegant digital experiences with a strong point of view.</h2>
            </div>
            <p className="max-w-xl text-sm leading-6 text-[var(--muted)] sm:text-right">
              Each project balances identity, usability, and front-end craft so the final result feels refined both visually
              and technically.
            </p>
          </div>

          <div className="mt-8 grid gap-6 lg:grid-cols-3">
            {featuredWork.map((project, index) => (
              <article
                key={project.name}
                className="rounded-[32px] border border-[var(--line)] bg-white/72 p-4 shadow-[0_24px_70px_-44px_rgba(0,0,0,0.55)] backdrop-blur-xl"
              >
                <div
                  className="relative h-60 overflow-hidden rounded-[26px] p-5 text-white"
                  style={{ backgroundImage: project.gradient }}
                >
                  <div className="absolute inset-0 bg-[radial-gradient(circle_at_top_left,rgba(255,255,255,0.22),transparent_32%)]" />
                  <div className="relative flex h-full flex-col justify-between">
                    <div className="flex items-center justify-between text-[11px] uppercase tracking-[0.24em] text-white/80">
                      <span>{project.category}</span>
                      <span>0{index + 1}</span>
                    </div>

                    <div className="grid grid-cols-[1.45fr_1fr] gap-3">
                      <div className="rounded-[22px] border border-white/20 bg-white/10 p-4 backdrop-blur-sm">
                        <div className="h-2 w-20 rounded-full bg-white/85" />
                        <div className="mt-4 h-24 rounded-[18px] border border-white/10 bg-black/10" />
                      </div>
                      <div className="space-y-3">
                        <div className="h-16 rounded-[18px] border border-white/20 bg-black/10" />
                        <div className="grid grid-cols-2 gap-3">
                          <div className="h-12 rounded-[18px] border border-white/20 bg-white/10" />
                          <div className="h-12 rounded-[18px] border border-white/20 bg-white/10" />
                        </div>
                      </div>
                    </div>
                  </div>
                </div>

                <div className="px-2 pb-2 pt-5">
                  <h3 className="text-2xl font-semibold tracking-tight">{project.name}</h3>
                  <p className="mt-3 text-sm leading-6 text-[var(--muted)]">{project.description}</p>

                  <ul className="mt-5 space-y-2 text-sm text-[var(--muted)]">
                    {project.bullets.map((bullet) => (
                      <li key={bullet} className="flex items-center gap-3">
                        <span className="h-1.5 w-1.5 rounded-full bg-[var(--accent)]" />
                        <span>{bullet}</span>
                      </li>
                    ))}
                  </ul>
                </div>
              </article>
            ))}
          </div>
        </section>

        <section id="services" className="mx-auto mt-20 max-w-6xl">
          <div className="rounded-[36px] border border-[var(--line)] bg-white/65 p-8 shadow-[0_24px_80px_-55px_rgba(0,0,0,0.55)] backdrop-blur-xl lg:p-10">
            <div className="max-w-2xl">
              <p className="text-xs font-medium uppercase tracking-[0.24em] text-[var(--muted)]">Services</p>
              <h2 className="mt-3 text-3xl font-semibold tracking-tight sm:text-4xl">
                Simple systems that make brands feel clear, premium, and easy to trust.
              </h2>
            </div>

            <div className="mt-8 grid gap-4 md:grid-cols-2 xl:grid-cols-4">
              {services.map((service, index) => (
                <div key={service.title} className="rounded-[28px] border border-[var(--line)] bg-[var(--surface-strong)] p-6">
                  <p className="text-xs font-medium uppercase tracking-[0.22em] text-[var(--muted)]">0{index + 1}</p>
                  <h3 className="mt-4 text-xl font-semibold tracking-tight">{service.title}</h3>
                  <p className="mt-3 text-sm leading-6 text-[var(--muted)]">{service.text}</p>
                </div>
              ))}
            </div>
          </div>
        </section>

        <section id="about" className="mx-auto mt-20 grid max-w-6xl gap-6 lg:grid-cols-[1.05fr_0.95fr]">
          <div className="rounded-[36px] border border-[var(--line)] bg-[var(--surface)] p-8 backdrop-blur-xl lg:p-10">
            <p className="text-xs font-medium uppercase tracking-[0.24em] text-[var(--muted)]">Approach</p>
            <h2 className="mt-3 text-3xl font-semibold tracking-tight sm:text-4xl">
              Good design feels effortless because every decision has already been considered.
            </h2>
            <p className="mt-5 max-w-2xl text-base leading-7 text-[var(--muted)]">
              My process stays intentionally focused: fewer distractions, better hierarchy, stronger typography, and clean
              interactions that support the content rather than overpower it.
            </p>

            <div className="mt-8 rounded-[28px] border border-[var(--line)] bg-white/70 p-6">
              <p className="text-sm leading-7 text-[var(--muted)]">
                The goal is not just to make things look better. It is to create a visual presence that feels cohesive,
                confident, and useful across every touchpoint.
              </p>
            </div>
          </div>

          <div className="grid gap-4">
            {principles.map((item) => (
              <div key={item.step} className="rounded-[30px] border border-[var(--line)] bg-white/72 p-6 shadow-[0_18px_60px_-48px_rgba(0,0,0,0.65)]">
                <div className="flex items-center justify-between gap-4">
                  <h3 className="text-xl font-semibold tracking-tight">{item.title}</h3>
                  <span className="text-xs font-medium uppercase tracking-[0.24em] text-[var(--muted)]">{item.step}</span>
                </div>
                <p className="mt-3 text-sm leading-6 text-[var(--muted)]">{item.text}</p>
              </div>
            ))}
          </div>
        </section>

        <section id="contact" className="mx-auto mt-20 max-w-6xl">
          <div className="rounded-[40px] border border-[#171717] bg-[#171717] px-8 py-10 text-white shadow-[0_30px_100px_-50px_rgba(0,0,0,0.75)] lg:flex lg:items-end lg:justify-between lg:px-10 lg:py-12">
            <div className="max-w-2xl">
              <p className="text-xs font-medium uppercase tracking-[0.24em] text-white/60">Let’s work together</p>
              <h2 className="mt-3 text-3xl font-semibold tracking-tight sm:text-4xl">
                Looking for a refined identity or a clean, modern website?
              </h2>
              <p className="mt-4 text-sm leading-7 text-white/70 sm:text-base">
                I’m available for freelance projects, portfolio sites, brand refreshes, and design-forward front-end work.
              </p>
            </div>

            <div className="mt-8 flex flex-wrap gap-3 lg:mt-0 lg:justify-end">
              <a
                href="mailto:hello@dbs.studio"
                className="rounded-full bg-white px-5 py-3 text-sm font-medium text-[#171717] transition hover:bg-[#f3ede5]"
              >
                hello@dbs.studio
              </a>
              <a
                href="#top"
                className="rounded-full border border-white/20 px-5 py-3 text-sm font-medium text-white transition hover:bg-white/10"
              >
                Back to top
              </a>
            </div>
          </div>
        </section>
      </main>

      <footer className="px-6 pb-10 lg:px-10">
        <div className="mx-auto flex max-w-6xl flex-col gap-3 border-t border-[var(--line)] pt-6 text-sm text-[var(--muted)] sm:flex-row sm:items-center sm:justify-between">
          <p>DBS Studio — graphic designer & web developer.</p>
          <p>© {year} All rights reserved.</p>
        </div>
      </footer>
    </div>
  );
}
